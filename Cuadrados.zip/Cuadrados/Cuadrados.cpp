#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture textura1;
Texture textura2;
Texture textura3;
Texture textura4;
Sprite sprite1;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;

int main() {

    textura1.loadFromFile("cuad_blue.png");
    sprite1.setTexture(textura1);
    sprite1.setPosition(0, 256);
    float alto = 256.0 / textura1.getSize().x;
    float ancho = 256.0 / textura1.getSize().y;
    sprite1.setScale(alto, ancho);

    textura2.loadFromFile("cuad_grey.png");
    sprite2.setTexture(textura2);
    sprite2.setPosition(256, 256);
    alto = 256.0 / textura2.getSize().x;
    ancho = 256.0 / textura2.getSize().y;
    sprite2.setScale(alto, ancho);

    textura3.loadFromFile("cuad_yellow.png");
    sprite3.setTexture(textura3);
    sprite3.setPosition(256, 0);
    alto = 256.0 / textura3.getSize().x;
    ancho = 256.0 / textura3.getSize().y;
    sprite3.setScale(alto, ancho);

    textura4.loadFromFile("cuad_red.png");
    sprite4.setTexture(textura4);
    sprite4.setPosition(0, 0);
    alto = 256.0 / textura4.getSize().x;
    ancho = 256.0 / textura4.getSize().y;
    sprite4.setScale(alto, ancho);

    RenderWindow Ventana(VideoMode(512, 512), "Cuadrados");

    while (Ventana.isOpen()) {

        Ventana.clear();

        Ventana.draw(sprite1);
        Ventana.draw(sprite2);
        Ventana.draw(sprite3);
        Ventana.draw(sprite4);

        Ventana.display();
    }
    return 0;
}
